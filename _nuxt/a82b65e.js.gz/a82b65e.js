(window.webpackJsonp=window.webpackJsonp||[]).push([[102],{1134:function(p,n,t){"use strict";t.r(n);var r=t(577),s=t(247),e=function(){var a=this,l=a._self._c;return l(r.a,{staticClass:"ma-2",attrs:{link:"",color:"primary",label:"",small:""},on:{click:function(k){return a.$router.push({path:"/list"})}}},[l(s.a,{attrs:{left:""}},[a._v(" mdi-arrow-left")]),a._v(`
  All list
`)],1)},c=[],i={name:"BackList"},o=i,v=t(50),u=Object(v.a)(o,e,c,!1,null,null,null),d=n.default=u.exports}}]);
