(window.webpackJsonp=window.webpackJsonp||[]).push([[96],{1121:function(d,a,n){"use strict";n.r(a);var r=function(){var t=this,s=t._self._c;return s("v-chip",{staticClass:"ma-2",attrs:{link:"",color:"primary",label:"",small:""},on:{click:function(B){return t.$router.push({path:"/list"})}}},[s("v-icon",{attrs:{left:""}},[t._v(" mdi-arrow-left")]),t._v(`
    All list
  `)],1)},o=[],i={name:"BackList"},c=i,v=n(50),e=n(51),p=n.n(e),u=n(578),m=n(247),l=Object(v.a)(c,r,o,!1,null,null,null),f=a.default=l.exports;p()(l,{VChip:u.a,VIcon:m.a})}}]);
