(window.webpackJsonp=window.webpackJsonp||[]).push([[66],{1137:function(d,a,t){"use strict";t.r(a);var r=function(){var n=this,f=n.$createElement,s=n._self._c||f;return s("v-chip",{staticClass:"ma-2",attrs:{link:"",color:"primary",label:"",small:""},on:{click:function(C){return n.$router.push({path:"/list"})}}},[s("v-icon",{attrs:{left:""}},[n._v(" mdi-arrow-left")]),n._v(`
  All list
`)],1)},o=[],i={name:"BackList"},v=i,c=t(50),e=t(51),p=t.n(e),m=t(574),u=t(246),l=Object(c.a)(v,r,o,!1,null,null,null),h=a.default=l.exports;p()(l,{VChip:m.a,VIcon:u.a})}}]);
